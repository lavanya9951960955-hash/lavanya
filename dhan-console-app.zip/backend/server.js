
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

const USERS_FILE = './users.json';
const TRANSACTIONS_FILE = './transactions.json';

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        res.json({ success: true, message: "Login successful" });
    } else {
        res.status(401).json({ success: false, message: "Invalid credentials" });
    }
});

app.get('/profit-loss/:period', (req, res) => {
    const period = req.params.period;
    const transactions = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8'));
    const now = new Date();
    let filtered = transactions.filter(t => {
        const ts = new Date(t.timestamp);
        if (period === 'daily') {
            return ts.toDateString() === now.toDateString();
        } else if (period === 'weekly') {
            const oneWeekAgo = new Date(now);
            oneWeekAgo.setDate(now.getDate() - 7);
            return ts >= oneWeekAgo;
        } else if (period === 'monthly') {
            return ts.getMonth() === now.getMonth() && ts.getFullYear() === now.getFullYear();
        }
    });

    let profitLoss = 0;
    filtered.forEach(t => {
        const sign = t.type === 'BUY' ? -1 : 1;
        profitLoss += sign * t.quantity * t.price;
    });

    res.json({ period, profitLoss, transactions: filtered });
});

app.listen(PORT, () => {
    console.log(`Backend running at http://localhost:${PORT}`);
});
