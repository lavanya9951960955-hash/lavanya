
import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [history, setHistory] = useState([]);
    const [command, setCommand] = useState('');

    const login = async () => {
        try {
            await axios.post('http://localhost:5000/login', { username, password });
            setIsLoggedIn(true);
        } catch {
            alert('Invalid credentials');
        }
    };

    const executeCommand = async (e) => {
        if (e.key === 'Enter') {
            const trimmed = command.trim();

            if (trimmed.startsWith('show pnl')) {
                const period = trimmed.split(' ')[2];
                const res = await axios.get(`http://localhost:5000/profit-loss/${period}`);
                const output = `P&L (${res.data.period}): ₹${res.data.profitLoss}`;
                setHistory(prev => [...prev, `> ${trimmed}`, output]);
            } else if (trimmed === 'logout') {
                setIsLoggedIn(false);
                setHistory([]);
                setUsername('');
                setPassword('');
            } else {
                setHistory(prev => [...prev, `> ${trimmed}`, 'Unknown command']);
            }

            setCommand('');
        }
    };

    if (!isLoggedIn) {
        return (
            <div className="login">
                <h2>Dhan Demat Console Login</h2>
                <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
                <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
                <button onClick={login}>Login</button>
            </div>
        );
    }

    return (
        <div className="console">
            <div className="output">
                {history.map((line, idx) => <div key={idx}>{line}</div>)}
            </div>
            <input
                type="text"
                placeholder="Enter command (e.g., show pnl daily)"
                value={command}
                onChange={e => setCommand(e.target.value)}
                onKeyDown={executeCommand}
                autoFocus
            />
        </div>
    );
}

export default App;
